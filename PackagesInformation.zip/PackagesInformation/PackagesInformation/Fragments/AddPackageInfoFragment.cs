﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Support.V4.App;
using Fragment = Android.Support.V4.App.Fragment;
using PackagesInformation.Model;
using Android.Text;
using Android.Content.Res;

namespace PackagesInformation.Fragments
{
    public class AddPackageInfoFragment : Fragment
    {
        private Context context ;
        private View _view;
        private Button _saveButton;
        private Button _resetButton;
        private EditText _barCodeEditText;
        private EditText _widthEditText;
        private EditText _heightEditText;
        private EditText _depthEditText;

        List<PackageInformationModel> listOfPackages = new List<PackageInformationModel>();
        public AddPackageInfoFragment(Context context)
        {
            this.context = context;
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment

            // Use this to return your custom view for this Fragment
            if (_view == null)
            {
                _view = inflater.Inflate(Resource.Layout.add_package_fragment_layout, container, false);
                _saveButton = (Button)_view.FindViewById(Resource.Id.save_button);
                _resetButton = (Button)_view.FindViewById(Resource.Id.reset_button);

                _barCodeEditText = (EditText)_view.FindViewById(Resource.Id.edittxtEnterBarcode);
                _widthEditText = (EditText)_view.FindViewById(Resource.Id.edittxtWidth);
                _heightEditText = (EditText)_view.FindViewById(Resource.Id.edittxtHeight);
                _depthEditText = (EditText)_view.FindViewById(Resource.Id.edittxtDepth);
                _widthEditText.TextChanged += OnTextChanged;
                _heightEditText.TextChanged += OnTextChanged;
                _depthEditText.TextChanged += OnTextChanged;
                _barCodeEditText.TextChanged += OnTextChanged;
                _saveButton.Click += SaveButtonClick;
                _resetButton.Click += ResetButtonClick;
            }
            return _view;
        }

        private void OnTextChanged(object sender, EventArgs e)
        {
            EditText editText = (EditText)sender;
            if(editText!=null && !string.IsNullOrEmpty(editText.Text))
            {
                ColorStateList colorStateList = ColorStateList.ValueOf(Android.Graphics.Color.Gray);
                editText.BackgroundTintList = colorStateList;
            }
        }

        private void ResetButtonClick(object sender, EventArgs e)
        {
            if (_barCodeEditText!=null &&!string.IsNullOrEmpty(_barCodeEditText.Text))
            {
                _barCodeEditText.Text = string.Empty;
            }
            if (_widthEditText!=null && !string.IsNullOrEmpty(_widthEditText.Text))
            {
                _widthEditText.Text = string.Empty;
            }
            if (_heightEditText!=null && !string.IsNullOrEmpty(_heightEditText.Text))
            {
                _heightEditText.Text = string.Empty;
            }
            if (_depthEditText!=null && !string.IsNullOrEmpty(_depthEditText.Text))
            {
                _depthEditText.Text = string.Empty;
            }
        }

        private void SaveButtonClick(object sender, EventArgs e)
        {
            bool isValidationSuccessful = CheckValidations();
            if (isValidationSuccessful && !string.IsNullOrEmpty(_barCodeEditText.Text) &&
                 !string.IsNullOrEmpty(_widthEditText.Text) &&
                    !string.IsNullOrEmpty(_heightEditText.Text) &&
                         !string.IsNullOrEmpty(_depthEditText.Text)) {
                bool isSavedSuccessfully = DataAccessManager.DataAccessManager.GetInstance().AddPackageInformation(_barCodeEditText.Text, _widthEditText.Text, _heightEditText.Text, _depthEditText.Text);
                if (isSavedSuccessfully)
                {
                    ShowToastMsg("dimms" + "( " + _widthEditText.Text + " x " + _heightEditText.Text + " x " + _depthEditText.Text + " ) " + _barCodeEditText.Text + " Saved Successfully");

                }
            }

        }

        private bool CheckValidations()
        {
            bool isValidationSuccessful = true;

            if (_barCodeEditText != null && string.IsNullOrEmpty(_barCodeEditText.Text))
            {
                isValidationSuccessful = false;
                ChangeColorOfBeloeLine(_barCodeEditText);
               
            }
            if (_widthEditText != null && string.IsNullOrEmpty(_widthEditText.Text))
            {
                isValidationSuccessful = false;
                ChangeColorOfBeloeLine(_widthEditText);
            }
            if (_heightEditText != null && string.IsNullOrEmpty(_heightEditText.Text))
            {
                isValidationSuccessful = false;
                ChangeColorOfBeloeLine(_heightEditText);
            }
            if (_depthEditText != null && string.IsNullOrEmpty(_depthEditText.Text))
            {
                isValidationSuccessful = false;
                ChangeColorOfBeloeLine(_depthEditText);
            }
            return isValidationSuccessful;
        }

        private void ChangeColorOfBeloeLine(EditText editText)
        {
            ColorStateList colorStateList = ColorStateList.ValueOf(Android.Graphics.Color.Red);
            editText.BackgroundTintList = colorStateList;
            ShowToastMsg(context.GetString(Resource.String.mandotoy_msg));
        }
        private void ShowToastMsg(string msg)
        {
            Toast.MakeText(context, msg, ToastLength.Long).Show();
        }
    }
}