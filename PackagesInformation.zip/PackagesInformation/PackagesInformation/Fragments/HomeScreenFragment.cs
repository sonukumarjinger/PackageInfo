﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Support.V4.App;
using Fragment = Android.Support.V4.App.Fragment;
using FragmentTransaction = Android.Support.V4.App.FragmentTransaction;

namespace PackagesInformation.Fragments
{
    public class HomeScreenFragment :  Fragment
    {
        private Context context;
        private View _view;
        private Button _addPackageButton;
        private Button _showAllPackageButton;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }
        public HomeScreenFragment(Context context)
        {
            this.context = context;
        }
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            if (_view == null)
            {
                _view = inflater.Inflate(Resource.Layout.home_fragment_layout, container, false);
                _addPackageButton = (Button)_view.FindViewById(Resource.Id.add_package);
                _showAllPackageButton = (Button)_view.FindViewById(Resource.Id.show_package);
                _showAllPackageButton.Click += ShowAllPackagesButtonClick;
                _addPackageButton.Click += AddPackagesButtonClick;
              
            }
            return _view;
        }

        private void AddPackagesButtonClick(object sender, EventArgs e)
        {
            AddPackageInfoFragment addPackageInfoFragment = new AddPackageInfoFragment(context);

            FragmentTransaction transaction = FragmentManager.BeginTransaction();
            transaction.Replace(Resource.Id.fragments, addPackageInfoFragment); // give your fragment container id in first parameter
            transaction.AddToBackStack(null);  // if written, this transaction will be added to backstack
            transaction.Commit();
        }

        private void ShowAllPackagesButtonClick(object sender, EventArgs e)
        {
            ShowAllPackageInfoFragment showAllPackageInfoFragment = new ShowAllPackageInfoFragment(context);

            FragmentTransaction transaction = FragmentManager.BeginTransaction();
            transaction.Replace(Resource.Id.fragments, showAllPackageInfoFragment); // give your fragment container id in first parameter
            transaction.AddToBackStack(null);  // if written, this transaction will be added to backstack
            transaction.Commit();

        }
    }
}