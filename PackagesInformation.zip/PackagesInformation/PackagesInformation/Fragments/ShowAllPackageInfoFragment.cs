﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Support.V4.App;
using Fragment = Android.Support.V4.App.Fragment;
using System.Threading.Tasks;

namespace PackagesInformation.Fragments
{
    public class ShowAllPackageInfoFragment : Fragment
    {
        private Context context;
        private View _view;

        public ShowAllPackageInfoFragment(Context context)
        {
            this.context = context;
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

           
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            if (_view == null)
            {
                _view = inflater.Inflate(Resource.Layout.package_Info_screen, container, false);
                var packageInformationList = DataAccessManager.DataAccessManager.GetInstance().GetAllPackagesInfo();
                if (packageInformationList != null && packageInformationList.Count > 0)
                {
                    var packagesInfoListAdapter = new PackagesInfoListAdapter(packageInformationList, context);
                    var recyclerView = _view.FindViewById<Android.Support.V7.Widget.RecyclerView>(Resource.Id.recyclerView);
                    var layoutManager = new Android.Support.V7.Widget.LinearLayoutManager(context);
                    recyclerView.SetLayoutManager(layoutManager);
                    recyclerView.SetAdapter(packagesInfoListAdapter);
                }
                else { 
                    Toast.MakeText(context, "No Data Available", ToastLength.Long).Show();
                }
            }
            return _view;
        }
    }
}