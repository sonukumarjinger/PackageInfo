﻿using System;
using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using PackagesInformation.DataBaseManager;
using PackagesInformation.Fragments;

namespace PackagesInformation
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar", MainLauncher = true)]
    public class HomeActivity : AppCompatActivity
    {

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            AppSchema appSchema = new AppSchema();
            appSchema.CreateDatabaseSchema();

            SetContentView(Resource.Layout.activity_main);

            Android.Support.V7.Widget.Toolbar toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);
            HomeScreenFragment homeScreenFragment = new HomeScreenFragment(this);
            Android.Support.V4.App.FragmentTransaction fragmentTransaction = this.SupportFragmentManager.BeginTransaction();
            fragmentTransaction.Add(Resource.Id.fragments, homeScreenFragment, "homeScreenFragment");
            fragmentTransaction.AddToBackStack(null);
            fragmentTransaction.CommitAllowingStateLoss();
        }

	}
}

