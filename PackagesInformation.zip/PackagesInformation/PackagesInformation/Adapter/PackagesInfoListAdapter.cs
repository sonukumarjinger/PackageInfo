﻿using Android.Content;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using PackagesInformation.Model;
using System;
using System.Collections.Generic;


namespace PackagesInformation
{
    class PackagesInfoListAdapter : RecyclerView.Adapter
    {
        private Context context;
        List<PackageInformationModel> packageInformationList = new List<PackageInformationModel>();

        public PackagesInfoListAdapter(List<PackageInformationModel> packageInformationList, Context context)
        {
            this.packageInformationList = packageInformationList;
            this.context = context;
        }

        public override int ItemCount
        {
            get { return packageInformationList.Count; }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            PackagesInfoListViewHolder packagesInfoListViewHolder = holder as PackagesInfoListViewHolder;

            packagesInfoListViewHolder.barCode.Text = "Barcode: "+ packageInformationList[position].Barcode;
            packagesInfoListViewHolder.txtdepth.Text ="D :"+ packageInformationList[position].Depth;
            packagesInfoListViewHolder.txtheight.Text = "H :" + packageInformationList[position].Height;
            packagesInfoListViewHolder.txtwidth.Text = "W :" + packageInformationList[position].Width;

        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            View itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.packages_item, parent, false);
            PackagesInfoListViewHolder errorListViewHolder = new PackagesInfoListViewHolder(itemView, packageInformationList);
            return errorListViewHolder;

        }
    }
    public class PackagesInfoListViewHolder : RecyclerView.ViewHolder
    {

        List<PackageInformationModel> packageInformationList = new List<PackageInformationModel>();
        public TextView barCode, txtwidth, txtheight, txtdepth;
        public PackagesInfoListViewHolder(View itemView, List<PackageInformationModel> packageInformationList) : base(itemView)
        {
            this.packageInformationList = packageInformationList;

            barCode = itemView.FindViewById<TextView>(Resource.Id.barCode);
            txtwidth = itemView.FindViewById<TextView>(Resource.Id.txtwidth);
            txtheight = itemView.FindViewById<TextView>(Resource.Id.txtheight);
            txtdepth = itemView.FindViewById<TextView>(Resource.Id.txtdepth);
        }

    }
}