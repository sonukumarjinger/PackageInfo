﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Mono.Data.Sqlite;
using PackagesInformation.Model;

namespace PackagesInformation.DataAccessManager
{
    class DataAccessManager
    {

        private static object locker = new object();
        private SqliteConnection db_connection;
        private static DataAccessManager Instance;

        private DataAccessManager()
        {
            string folder = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);

            string path = Path.Combine(folder, "Database.db3");
            db_connection = new SqliteConnection("Data Source=" + path);
            db_connection.Open();
        }

        /// <summary>
        /// Will return the instance of the database
        /// </summary>
        /// <returns></returns>
        public static DataAccessManager GetInstance()
        {
            lock (locker)
            {
                if (Instance == null)
                {
                    Instance = new DataAccessManager();
                }
                //Opening again if db get close
                if (Instance.db_connection != null && Instance.db_connection.State != System.Data.ConnectionState.Open)
                {
                    Instance.db_connection.Open();
                }
            }
            return Instance;
        }


        public bool AddPackageInformation(string barcode, string width, string height, string depth)
        {
            try
            {

                var query =
                    @"INSERT INTO PackageInformation (Barcode, Width, Height, Depth) VALUES(?, ?, ?, ?)";

                lock (locker)
                {
                    if (db_connection != null && db_connection.State != System.Data.ConnectionState.Open)
                    {
                        db_connection.Open();
                    }
                    using (var command = db_connection.CreateCommand())
                    {
                        command.CommandText = query;
                        command.Parameters.Add(new SqliteParameter(DbType.String) { Value = barcode });
                        command.Parameters.Add(new SqliteParameter(DbType.String) { Value = width });
                        command.Parameters.Add(new SqliteParameter(DbType.String) { Value = height });
                        command.Parameters.Add(new SqliteParameter(DbType.String) { Value = depth });
                        var result = command.ExecuteNonQuery();

                        command.Dispose();
                    }
                    if (db_connection != null && db_connection.State != System.Data.ConnectionState.Closed)
                    {
                        db_connection.Close();
                    }
                }
                return true;
            }
            catch (Exception e)
            {

                if (db_connection != null && db_connection.State != System.Data.ConnectionState.Closed)
                {
                    db_connection.Close();
                }
                Console.WriteLine("Error" + e.Message.ToString());
                return false;
            }

        }
        public List<PackageInformationModel> GetAllPackagesInfo()
        {
            List<PackageInformationModel> packageInformationList = new List<PackageInformationModel>();
            var query = "SELECT * FROM PackageInformation";

            DataTable datatable = new DataTable();
            using (var va = new SqliteDataAdapter())
            {
                va.SelectCommand = new SqliteCommand(db_connection);
                va.SelectCommand.CommandText = query;
                va.Fill(datatable);
            }

            if (datatable != null && datatable.Rows != null && datatable.Rows.Count >= 0)
            {
                packageInformationList = ConvertDataTable<PackageInformationModel>(datatable);
            }
            datatable.Dispose();

            return packageInformationList;
        }

        private List<T> ConvertDataTable<T>(DataTable datatable)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in datatable.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }

        private T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                    {
                        var type = pro.Name.GetType();
                        if (dr[column.ColumnName] == DBNull.Value)
                        {
                            if (type == typeof(string) && dr[column.ColumnName].GetType() == pro.Name.GetType())
                            {
                                pro.SetValue(obj, string.Empty, null);
                            }
                            else
                            {
                                pro.SetValue(obj, null, null);
                            }
                        }
                        else
                        {
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        }
                    }
                    else
                        continue;
                }
            }
            return obj;
        }
    }
}