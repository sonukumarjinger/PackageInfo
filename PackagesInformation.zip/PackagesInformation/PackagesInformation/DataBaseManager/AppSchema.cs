﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Mono.Data.Sqlite;

namespace PackagesInformation.DataBaseManager
{

    public class AppSchema
    {

        public SqliteConnection connection;
        public void CreateDatabaseSchema()
        {
            string folder = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);

            string path = Path.Combine(folder,"Database.db3");
            bool exists = File.Exists(folder);
            if (!exists)
            {
                connection = new SqliteConnection("Data Source=" + path);
                connection.Open();
                var SchemaCreateCommand = new[]
                {
                    "CREATE TABLE IF NOT EXISTS [PackageInformation] (Barcode NTEXT,Width NTEXT,Height NTEXT, Depth NTEXT, PRIMARY KEY (Barcode))"
                };

                try
                {
                    foreach (var command in SchemaCreateCommand)
                    {
                        using (var c = connection.CreateCommand())
                        {
                            c.CommandText = command;
                            c.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {

                    System.Console.WriteLine(ex.Message);
                }
                finally
                {
                    connection.Close();
                }

            }
        }
       
    }
}