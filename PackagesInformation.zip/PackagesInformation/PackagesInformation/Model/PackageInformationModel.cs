﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace PackagesInformation.Model
{
    public class PackageInformationModel
    {
        public string Barcode { set; get; }

        public string Width { set; get; }

        public string Height { set; get; }

        public string Depth { set; get; }
    }
}